package com.swerksentrum.stellenboschworkcentre.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swerksentrum.stellenboschworkcentre.ui.components.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

@Composable
private fun InfoBlock(label: String, vararg lines: String) {
    Text(label, fontWeight = FontWeight.Bold)
    lines.forEach { Text(it) }
    Spacer(Modifier.height(16.dp))
}

@Composable
private fun FormField(label: String, value: String, onChange: (String) -> Unit, minLines: Int = 1) {
    Text(label, fontSize = 12.sp, color = SwcColors.Label)
    Spacer(Modifier.height(5.dp))
    SwcTextField(value, onChange, singleLine = minLines == 1, minLines = minLines)
    Spacer(Modifier.height(14.dp))
}

@Composable
fun ContactScreen(
    modifier: Modifier = Modifier,
    onNavigate: (String) -> Unit = {},
    onSend: (name: String, email: String, subject: String, message: String) -> Unit = { _, _, _, _ -> }
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    SwcScaffold("contact", onNavigate, modifier) {
        SwcSection(cream = true) {
            SwcTitle("Get In Touch")
            Spacer(Modifier.height(22.dp))
            SwcSub("Have questions? We'd love to hear from you. Send us a message and we'll respond as soon as possible.")
            Spacer(Modifier.height(30.dp))

            Text("Contact Information", color = SwcColors.Green, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            InfoBlock("Address", "Stellenbosch, Western Cape, South Africa")
            InfoBlock("Phone", "+27 17 123 4567", "+27 21 555 0100")
            InfoBlock("Email", "info@stellenboschwork.org")
            InfoBlock("Office Hours", "Monday - Friday: 8:00 AM - 5:00 PM", "Saturday: 9:00 AM - 1:00 PM")

            Spacer(Modifier.height(34.dp))
            val shape = RoundedCornerShape(14.dp)
            Column(
                Modifier.fillMaxWidth()
                    .shadow(8.dp, shape, ambientColor = Color(0x1A000000), spotColor = Color(0x1A000000))
                    .background(Color.White, shape).border(1.dp, SwcColors.FormBorder, shape).padding(25.dp)
            ) {
                Text("Send Us a Message", color = SwcColors.Green, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                FormField("Full Name", name, { name = it })
                FormField("Email Address", email, { email = it })
                FormField("Subject", subject, { subject = it })
                FormField("Message", message, { message = it }, minLines = 5)
                SwcButton("Send Message", SwcButtonStyle.Green, Modifier.fillMaxWidth()) {
                    onSend(name, email, subject, message)
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun ContactScreenPreview() = ContactScreen()
