package com.swerksentrum.stellenboschworkcentre.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swerksentrum.stellenboschworkcentre.ui.components.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

data class ChatMessage(val text: String, val fromUser: Boolean)

private val greeting = ChatMessage(
    "Hello! I’m the Stellenbosch Work Centre support assistant. I can help you with registrations, programs, donations, services, shop products and contact information. How can I help?",
    fromUser = false
)

private val quickQuestions = listOf(
    "How do I register?" to "How do I register?",
    "Available programs" to "What programs are available?",
    "Donation info" to "How can I donate?",
    "Our services" to "What services do you offer?"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChatbotScreen(
    messages: List<ChatMessage> = listOf(greeting),
    modifier: Modifier = Modifier,
    onNavigate: (String) -> Unit = {},
    onSend: (String) -> Unit = {}
) {
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }
    fun send(text: String) {
        val t = text.trim()
        if (t.isNotEmpty()) { onSend(t); input = "" }
    }

    SwcScaffold("chat", onNavigate, modifier, showAiButton = false) {
        val shape = RoundedCornerShape(14.dp)
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 24.dp).fillMaxWidth()
                .clip(shape).border(1.dp, SwcColors.FieldBorder, shape)
        ) {
            // Header
            Column(Modifier.fillMaxWidth().background(SwcColors.Green).padding(18.dp)) {
                Text("✦ AI Support Assistant", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Stellenbosch Work Centre • Online", color = Color.White, fontSize = 13.sp)
            }
            // Messages
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxWidth().height(430.dp).background(Color.White),
                contentPadding = PaddingValues(18.dp)
            ) {
                items(messages) { m ->
                    BoxWithConstraints(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        val maxBubble = maxWidth * 0.78f
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Text(
                                m.text,
                                color = if (m.fromUser) Color.White else Color(0xFF333333),
                                fontSize = 13.sp, lineHeight = 19.5.sp,
                                modifier = Modifier.widthIn(max = maxBubble)
                                    .background(
                                        if (m.fromUser) SwcColors.Green else SwcColors.BotBubble,
                                        RoundedCornerShape(
                                            topStart = 15.dp, topEnd = 15.dp,
                                            bottomEnd = if (m.fromUser) 4.dp else 15.dp,
                                            bottomStart = if (m.fromUser) 15.dp else 4.dp
                                        )
                                    ).padding(horizontal = 14.dp, vertical = 11.dp)
                            )
                        }
                    }
                }
            }
            // Quick replies
            FlowRow(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                quickQuestions.forEach { (label, question) ->
                    val chip = RoundedCornerShape(20.dp)
                    Text(
                        label, color = SwcColors.Green, fontSize = 13.33.sp,
                        modifier = Modifier.clip(chip).background(Color.White)
                            .border(1.dp, SwcColors.Green, chip)
                            .clickable { send(question) }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    )
                }
            }
            // Input
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                SwcTextField(
                    input, { input = it }, Modifier.weight(1f),
                    placeholder = "Type your message...", shape = RoundedCornerShape(22.dp),
                    highlightOnFocus = true, onSend = { send(input) }
                )
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(40.dp).background(SwcColors.Green, CircleShape).clickable { send(input) },
                    contentAlignment = Alignment.Center
                ) { Text("➤", color = Color.White) }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun ChatbotScreenPreview() = ChatbotScreen()
