package com.swerksentrum.stellenboschworkcentre.ui.components

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

enum class SwcButtonStyle { Outline, Green, Gold }

@Composable
fun SwcButton(
    text: String,
    style: SwcButtonStyle = SwcButtonStyle.Outline,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 16.sp,
    onClick: () -> Unit = {}
) {
    val bg = when (style) {
        SwcButtonStyle.Outline -> Color.White
        SwcButtonStyle.Green -> SwcColors.Green
        SwcButtonStyle.Gold -> SwcColors.Gold
    }
    val border = if (style == SwcButtonStyle.Gold) SwcColors.Gold else SwcColors.Green
    val fg = if (style == SwcButtonStyle.Outline) SwcColors.Green else Color.White
    val shape = RoundedCornerShape(28.dp)
    Box(
        modifier.clip(shape).background(bg).border(1.dp, border, shape)
            .clickable(onClick = onClick).padding(horizontal = 23.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontSize = fontSize) }
}

@Composable
fun SwcBrandMark() {
    Box(
        Modifier.padding(4.dp).size(26.dp).rotate(45f)
            .border(2.dp, SwcColors.Green, RoundedCornerShape(6.dp))
    )
}

private val navLinks = listOf(
    "home" to "Home", "about" to "About", "services" to "Services", "shop" to "Shop",
    "register" to "Register", "contact" to "Contact"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SwcHeader(current: String, onNavigate: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color.White)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                Modifier.clickable { onNavigate("home") },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SwcBrandMark()
                Text("Stellenbosch Work Centre", color = SwcColors.Green, fontSize = 18.sp)
            }
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                navLinks.forEach { (route, label) ->
                    Text(
                        label, fontSize = 12.sp,
                        fontWeight = if (route == current) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { onNavigate(route) }.padding(vertical = 12.dp)
                    )
                }
                Text(
                    "AI Support", fontSize = 12.sp, color = SwcColors.Green, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigate("chat") }.padding(vertical = 12.dp)
                )
                SwcButton("Donate", SwcButtonStyle.Gold, fontSize = 12.sp) { onNavigate("donate") }
            }
        }
        HorizontalDivider(color = SwcColors.HeaderBorder)
    }
}

/** Header + scrolling body + floating AI button, same as every website page. */
@Composable
fun SwcScaffold(
    current: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier,
    showAiButton: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    ProvideTextStyle(TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp, color = SwcColors.Text)) {
        Box(modifier.fillMaxSize().background(Color.White).statusBarsPadding()) {
            Column(Modifier.fillMaxSize()) {
                SwcHeader(current, onNavigate)
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), content = content)
            }
            if (showAiButton) {
                Box(
                    Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(22.dp)
                        .size(58.dp).shadow(8.dp, CircleShape).background(SwcColors.Green, CircleShape)
                        .clickable { onNavigate("chat") },
                    contentAlignment = Alignment.Center
                ) { Text("✦", color = Color.White, fontSize = 24.sp) }
            }
        }
    }
}

@Composable
fun SwcSection(cream: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(if (cream) SwcColors.Cream else Color.White)
            .padding(horizontal = 16.dp, vertical = 78.dp),
        content = content
    )
}

@Composable
fun SwcTitle(text: String, center: Boolean = true) = Text(
    text, color = SwcColors.Green, fontSize = 27.sp, fontWeight = FontWeight.Medium,
    textAlign = if (center) TextAlign.Center else TextAlign.Start, modifier = Modifier.fillMaxWidth()
)

@Composable
fun SwcSub(text: String) = Text(
    text, color = SwcColors.Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
)

@Composable
fun SwcCard(
    modifier: Modifier = Modifier,
    padding: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(13.dp)
    Column(
        modifier.fillMaxWidth()
            .shadow(6.dp, shape, ambientColor = Color(0x14000000), spotColor = Color(0x14000000))
            .clip(shape).background(Color.White).border(1.dp, SwcColors.CardBorder, shape).padding(padding),
        content = content
    )
}

@Composable
fun SwcTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    shape: Shape = RoundedCornerShape(8.dp),
    singleLine: Boolean = true,
    minLines: Int = 1,
    highlightOnFocus: Boolean = false,
    onSend: (() -> Unit)? = null
) {
    var focused by remember { mutableStateOf(false) }
    val borderColor = if (highlightOnFocus && focused) SwcColors.Green else SwcColors.FieldBorder
    BasicTextField(
        value = value, onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
        singleLine = singleLine, minLines = minLines,
        textStyle = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 13.33.sp, color = SwcColors.Text),
        cursorBrush = SolidColor(SwcColors.Green),
        keyboardOptions = KeyboardOptions(imeAction = if (onSend != null) ImeAction.Send else ImeAction.Default),
        keyboardActions = KeyboardActions(onSend = { onSend?.invoke() }),
        decorationBox = { inner ->
            Box(Modifier.clip(shape).background(Color.White).border(1.dp, borderColor, shape).padding(11.dp)) {
                if (value.isEmpty() && placeholder.isNotEmpty())
                    Text(placeholder, color = Color(0xFF757575), fontSize = 13.33.sp)
                inner()
            }
        }
    )
}
