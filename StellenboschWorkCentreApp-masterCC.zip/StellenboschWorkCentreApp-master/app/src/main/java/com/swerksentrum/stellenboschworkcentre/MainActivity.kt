package com.swerksentrum.stellenboschworkcentre

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.swerksentrum.stellenboschworkcentre.screens.AboutScreen
import com.swerksentrum.stellenboschworkcentre.screens.ChatMessage
import com.swerksentrum.stellenboschworkcentre.screens.ChatbotScreen
import com.swerksentrum.stellenboschworkcentre.screens.ContactScreen
import com.swerksentrum.stellenboschworkcentre.screens.ServicesScreen
import com.swerksentrum.stellenboschworkcentre.screens.ShopScreen
import com.swerksentrum.stellenboschworkcentre.ui.components.SwcScaffold
import com.swerksentrum.stellenboschworkcentre.ui.components.SwcSection
import com.swerksentrum.stellenboschworkcentre.ui.components.SwcSub
import com.swerksentrum.stellenboschworkcentre.ui.components.SwcTitle
import com.swerksentrum.stellenboschworkcentre.ui.theme.StellenboschWorkCentreTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StellenboschWorkCentreTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    AppRoot()
                }
            }
        }
    }
}

// Change to "home" once the Home screen is built.
private const val START_ROUTE = "about"

@Composable
fun AppRoot() {
    val nav = rememberNavController()

    val go: (String) -> Unit = { route ->
        nav.navigate(route) {
            popUpTo(START_ROUTE) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    // Chat demo state, using the same FAQ answers as the website.
    val scope = rememberCoroutineScope()
    val chat = remember {
        mutableStateListOf(
            ChatMessage(
                "Hello! I’m the Stellenbosch Work Centre support assistant. I can help you with registrations, programs, donations, services, shop products and contact information. How can I help?",
                fromUser = false
            )
        )
    }

    NavHost(navController = nav, startDestination = START_ROUTE) {
        composable("about") { AboutScreen(onNavigate = go) }
        composable("services") { ServicesScreen(onNavigate = go) }
        composable("shop") { ShopScreen(onNavigate = go) }
        composable("contact") { ContactScreen(onNavigate = go) }
        composable("chat") {
            ChatbotScreen(
                messages = chat,
                onNavigate = go,
                onSend = { text ->
                    chat.add(ChatMessage(text, fromUser = true))
                    scope.launch {
                        delay(250)
                        chat.add(ChatMessage(faqReply(text), fromUser = false))
                    }
                }
            )
        }

        // Screens that exist on the website but aren't built in the app yet.
        composable("home") { ComingSoon("Home", "home", go) }
        composable("register") { ComingSoon("Register", "register", go) }
        composable("donate") { ComingSoon("Donate", "donate", go) }
    }
}

@Composable
private fun ComingSoon(title: String, route: String, onNavigate: (String) -> Unit) {
    SwcScaffold(current = route, onNavigate = onNavigate) {
        SwcSection(cream = true) {
            SwcTitle(title)
            Spacer(Modifier.height(22.dp))
            SwcSub("This screen is coming soon.")
        }
    }
}

/** Same FAQ answers as the website's script.js. Your developer can swap this for real logic. */
private fun faqReply(message: String): String {
    val t = message.lowercase()
    val faq = listOf(
        listOf("register", "registration", "sign up", "beneficiary", "apply") to
                "You can register a beneficiary from the Register page. Complete the personal details form and continue to the program selection.",
        listOf("program", "programs", "training", "course") to
                "Our programs include Folding & Sorting, Office Work, Packaging and Handcrafts.",
        listOf("donate", "donation", "give", "money") to
                "You can make a donation from the Donate page. Choose an amount and a purpose, then continue with the donation process.",
        listOf("service", "services", "folding", "sorting", "packaging", "photocopy") to
                "Our services include Folding, Sorting, Packaging and Photocopying. Visit the Services page for details.",
        listOf("shop", "product", "products", "rug", "basket", "handmade") to
                "The shop offers handmade products including woven baskets, rugs, decorative wall art and ceramic items.",
        listOf("contact", "phone", "email", "address", "location") to
                "Visit the Contact page for our address, phone number, email and office information.",
        listOf("hello", "hi", "hey") to
                "Hello! I am the Stellenbosch Work Centre support assistant. I can help with registration, programs, donations, services, the shop and contact information.",
        listOf("help", "what can you do") to
                "I can answer questions about registration, available programs, donations, services, shop products and contacting the Work Centre."
    )
    return faq.firstOrNull { (keys, _) -> keys.any { t.contains(it) } }?.second
        ?: "I don't have an answer for that yet. Try asking about registration, programs, donations, services, the shop or contact details."
}