package com.swerksentrum.stellenboschworkcentre.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.swerksentrum.stellenboschworkcentre.ui.components.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

data class ShopProduct(val name: String, val description: String, val price: String, val imageUrl: String)

private const val blurb = "Beautiful handmade item supporting our artisans."

val defaultProducts = listOf(
    ShopProduct("Handwoven Nguni Rug", blurb, "R450", "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=900&q=85"),
    ShopProduct("Woven Basket Set", blurb, "R280", "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1100&q=85"),
    ShopProduct("Decorative Wall Art", blurb, "R350", "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=900&q=85"),
    ShopProduct("Ceramic Bowl Collection", blurb, "R320", "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=900&q=85")
)

@Composable
fun ShopScreen(
    products: List<ShopProduct> = defaultProducts,
    modifier: Modifier = Modifier,
    onNavigate: (String) -> Unit = {},
    onAddToCart: (ShopProduct) -> Unit = {},
    onViewFullShop: () -> Unit = {}
) {
    SwcScaffold("shop", onNavigate, modifier) {
        SwcSection(cream = true) {
            SwcTitle("Handmade with Love")
            Spacer(Modifier.height(22.dp))
            SwcSub("Every purchase supports our artisans and their journey to independence.")
            Spacer(Modifier.height(30.dp))
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                products.forEach { p ->
                    SwcCard(padding = 0.dp) {
                        AsyncImage(
                            model = p.imageUrl, contentDescription = p.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxWidth().height(145.dp)
                        )
                        Column(Modifier.padding(13.dp)) {
                            Text(p.name, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(p.description)
                            Spacer(Modifier.height(16.dp))
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(p.price, color = SwcColors.Green, fontSize = 18.sp)
                                Box(
                                    Modifier.size(29.dp).background(SwcColors.Green, CircleShape)
                                        .clickable { onAddToCart(p) },
                                    contentAlignment = Alignment.Center
                                ) { Text("+", color = Color.White) }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(25.dp))
            SwcButton("View Full Shop", SwcButtonStyle.Green, Modifier.align(Alignment.CenterHorizontally)) { onViewFullShop() }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun ShopScreenPreview() = ShopScreen()
