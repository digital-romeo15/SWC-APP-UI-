package com.swerksentrum.stellenboschworkcentre.ui.theme

import androidx.compose.ui.graphics.Color

object StelliesColours {
    val Green = Color(0xFF2F8137)
    val Gold = Color(0xFFD2A622)
    val Text = Color(0xFF303530)
    val Cream = Color(0xFFFBF8F2)
    val CardBorder = Color(0xFFE5E8E5)
    val HeaderBorder = Color(0xFFE5E7E5)
    val FormBorder = Color(0xFFE4E7E4)
    val FieldBorder = Color(0xFFDDDDDD)
    val Muted = Color(0xFF777777)
    val Label = Color(0xFF666666)
    val BotBubble = Color(0xFFFBF0E7)
}