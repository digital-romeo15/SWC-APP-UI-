package com.swerksentrum.stellenboschworkcentre.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.swerksentrum.stellenboschworkcentre.ui.components.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

@Composable
fun AboutScreen(modifier: Modifier = Modifier, onNavigate: (String) -> Unit = {}) {
    SwcScaffold("about", onNavigate, modifier) {
        SwcSection(cream = true) {
            AsyncImage(
                model = "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=900&q=85",
                contentDescription = "People collaborating around a table",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(370.dp).clip(RoundedCornerShape(18.dp))
            )
            Spacer(Modifier.height(55.dp))
            SwcTitle("About Our Mission", center = false)
            Spacer(Modifier.height(16.dp))
            Text("Stellenbosch Work Centre is dedicated to empowering adults with disabilities through comprehensive work training, skills development programs, and meaningful social inclusion initiatives.")
            Spacer(Modifier.height(16.dp))
            Text("We believe every individual deserves the opportunity to contribute, grow, and thrive.")
            Spacer(Modifier.height(16.dp))
            val shape = RoundedCornerShape(10.dp)
            Column(
                Modifier.fillMaxWidth()
                    .shadow(8.dp, shape, ambientColor = Color(0x1A000000), spotColor = Color(0x1A000000))
                    .background(Color.White, shape).padding(15.dp)
            ) {
                Text("Our Vision", color = SwcColors.Green, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Text("A community where every person, regardless of ability, has access to meaningful work opportunities and support.")
            }
            Spacer(Modifier.height(16.dp))
            SwcButton("Learn More", SwcButtonStyle.Green) { onNavigate("contact") }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun AboutScreenPreview() = AboutScreen()
