package com.swerksentrum.stellenboschworkcentre.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swerksentrum.stellenboschworkcentre.ui.components.*
import com.swerksentrum.stellenboschworkcentre.ui.theme.SwcColors

data class ServiceItem(val title: String, val description: String)

val defaultServices = listOf(
    ServiceItem("Folding Services", "Professional document folding and preparation for meetings, brochures, and promotional materials."),
    ServiceItem("Sorting Services", "Efficient sorting solutions for documents, products, and materials with attention to accuracy."),
    ServiceItem("Packaging Services", "Quality packaging and presentation services for products, gifts, boxes and promotional materials."),
    ServiceItem("Photocopying", "Reliable copying and printing services with fast turnaround times and competitive rates.")
)

@Composable
fun ServicesScreen(
    services: List<ServiceItem> = defaultServices,
    modifier: Modifier = Modifier,
    onNavigate: (String) -> Unit = {},
    onRequestService: (ServiceItem) -> Unit = { onNavigate("contact") }
) {
    SwcScaffold("services", onNavigate, modifier) {
        SwcSection {
            SwcTitle("Our Services")
            Spacer(Modifier.height(22.dp))
            SwcSub("High-quality services delivered by our dedicated team, supporting meaningful employment.")
            Spacer(Modifier.height(30.dp))
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                services.forEach { s ->
                    SwcCard {
                        Text(s.title, color = SwcColors.Green, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(16.dp))
                        Text(s.description)
                        Spacer(Modifier.height(32.dp))
                        SwcButton("Request Service") { onRequestService(s) }
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
private fun ServicesScreenPreview() = ServicesScreen()
